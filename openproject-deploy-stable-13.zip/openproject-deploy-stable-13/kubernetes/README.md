# OpenProject installation using Kubernetes

Please use the [OpenProject helm chart](https://charts.openproject.org) to install OpenProject on kubernetes.
