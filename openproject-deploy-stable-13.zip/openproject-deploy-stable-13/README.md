# OpenProject Deploy

Recipes and examples for deploying OpenProject.

* [Docker Compose](./compose/)
* [Kubernetes](./kubernetes/)
